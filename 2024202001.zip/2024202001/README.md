
# SSD Lab-1

We have to simply run the command on terminal for question-1
```bash
 ./2024202001_q1.sh 
```
and for question-2 type 
```bash
./2024202001_q2.sh
```
Here we need to care about present working directory which includes both above mentioned file. Also need to ensure tha two files which we have to process "power_levels.txt" and "access.log" are present in present working directory.
